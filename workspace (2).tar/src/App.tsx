import { useState, useEffect } from 'react';
import { roadmapData, phases, skillColors, skillIcons, type Topic } from './roadmapData';

function App() {
  const [completedTopics, setCompletedTopics] = useState<Set<string>>(() => {
    const saved = localStorage.getItem('ielts-completed-topics');
    return saved ? new Set(JSON.parse(saved)) : new Set();
  });
  const [expandedMonth, setExpandedMonth] = useState<number | null>(null);
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [showProgress, setShowProgress] = useState(false);

  useEffect(() => {
    localStorage.setItem('ielts-completed-topics', JSON.stringify([...completedTopics]));
  }, [completedTopics]);

  const toggleTopic = (topicId: string) => {
    setCompletedTopics((prev) => {
      const next = new Set(prev);
      if (next.has(topicId)) {
        next.delete(topicId);
      } else {
        next.add(topicId);
      }
      return next;
    });
  };

  const totalTopics = roadmapData.reduce((acc, month) => acc + month.topics.length, 0);
  const completedCount = completedTopics.size;
  const progressPercent = Math.round((completedCount / totalTopics) * 100);

  const getPhaseProgress = (phaseId: number) => {
    const phaseMonths = roadmapData.filter((m) => m.phase === phaseId);
    const phaseTopics = phaseMonths.reduce((acc, m) => acc + m.topics.length, 0);
    const phaseCompleted = phaseMonths.reduce(
      (acc, m) => acc + m.topics.filter((t) => completedTopics.has(t.id)).length,
      0
    );
    return phaseTopics > 0 ? Math.round((phaseCompleted / phaseTopics) * 100) : 0;
  };

  const filteredTopics = (topics: Topic[]) => {
    if (activeFilter === 'all') return topics;
    return topics.filter((t) => t.skill === activeFilter);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-lg shadow-lg">
                🎯
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold text-slate-800">IELTS Roadmap</h1>
                <p className="text-xs sm:text-sm text-slate-500">14-Month Preparation Plan</p>
              </div>
            </div>
            <button
              onClick={() => setShowProgress(!showProgress)}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors border border-indigo-200"
            >
              <span className="text-indigo-600 font-semibold text-sm">{progressPercent}%</span>
              <span className="text-indigo-400 text-sm">Complete</span>
            </button>
          </div>
        </div>
      </header>

      {/* Progress Panel */}
      {showProgress && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 p-6 animate-in">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-slate-800">Overall Progress</h2>
              <span className="text-sm text-slate-500">
                {completedCount} / {totalTopics} topics
              </span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-4 mb-6 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {phases.map((phase) => (
                <div key={phase.id} className="bg-slate-50 rounded-xl p-4 border border-slate-100">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold text-slate-700">{phase.name}</span>
                    <span className="text-xs text-slate-500">Months {phase.months}</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2 mb-1 overflow-hidden">
                    <div
                      className={`h-full rounded-full bg-gradient-to-r ${phase.color} transition-all duration-500`}
                      style={{ width: `${getPhaseProgress(phase.id)}%` }}
                    />
                  </div>
                  <span className="text-xs text-slate-500">{getPhaseProgress(phase.id)}% complete</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Filter Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
              activeFilter === 'all'
                ? 'bg-slate-800 text-white shadow-md'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            🎯 All Skills
          </button>
          {Object.entries(skillIcons).map(([skill, icon]) => (
            <button
              key={skill}
              onClick={() => setActiveFilter(skill)}
              className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all capitalize ${
                activeFilter === skill
                  ? `${skillColors[skill].bg} ${skillColors[skill].text} shadow-md border ${skillColors[skill].border}`
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {icon} {skill}
            </button>
          ))}
        </div>
      </div>

      {/* Timeline */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {phases.map((phase) => (
          <div key={phase.id} className="mb-12">
            {/* Phase Header */}
            <div className="flex items-center gap-3 mb-6">
              <div
                className={`px-4 py-2 rounded-xl bg-gradient-to-r ${phase.color} text-white font-bold text-sm shadow-lg`}
              >
                Phase {phase.id}
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-800">{phase.name}</h2>
                <p className="text-sm text-slate-500">Months {phase.months}</p>
              </div>
              <div className="ml-auto hidden sm:block">
                <div className="flex items-center gap-2">
                  <div className="w-24 bg-slate-200 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full rounded-full bg-gradient-to-r ${phase.color} transition-all duration-500`}
                      style={{ width: `${getPhaseProgress(phase.id)}%` }}
                    />
                  </div>
                  <span className="text-xs text-slate-500 font-medium">{getPhaseProgress(phase.id)}%</span>
                </div>
              </div>
            </div>

            {/* Month Cards */}
            <div className="space-y-4 ml-0 sm:ml-8 border-l-2 border-slate-200 pl-6">
              {roadmapData
                .filter((m) => m.phase === phase.id)
                .map((month) => {
                  const monthTopics = filteredTopics(month.topics);
                  const monthCompleted = month.topics.filter((t) => completedTopics.has(t.id)).length;
                  const monthTotal = month.topics.length;
                  const isExpanded = expandedMonth === month.month;

                  return (
                    <div key={month.month} className="relative">
                      {/* Timeline dot */}
                      <div
                        className={`absolute -left-[31px] top-6 w-4 h-4 rounded-full border-2 border-white shadow-md ${
                          monthCompleted === monthTotal
                            ? 'bg-green-500'
                            : monthCompleted > 0
                            ? 'bg-yellow-500'
                            : 'bg-slate-300'
                        }`}
                      />

                      <div
                        className={`bg-white rounded-2xl shadow-md border transition-all duration-300 ${
                          isExpanded ? 'border-indigo-300 shadow-xl ring-2 ring-indigo-100' : 'border-slate-200 hover:shadow-lg hover:border-slate-300'
                        }`}
                      >
                        {/* Month Header */}
                        <button
                          onClick={() => setExpandedMonth(isExpanded ? null : month.month)}
                          className="w-full text-left p-5 sm:p-6"
                        >
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-xs font-bold text-indigo-500 uppercase tracking-wide">
                                  Month {month.month}
                                </span>
                                <span className="text-xs text-slate-400">•</span>
                                <span className="text-xs text-slate-500">{month.weeklyHours}/week</span>
                              </div>
                              <h3 className="text-lg font-bold text-slate-800 mb-1">{month.title}</h3>
                              <p className="text-sm text-slate-500 line-clamp-2">{month.description}</p>
                            </div>
                            <div className="flex flex-col items-end gap-2">
                              <div className="flex items-center gap-1.5">
                                <span className="text-xs text-slate-500">
                                  {monthCompleted}/{monthTotal}
                                </span>
                                <div className="w-16 bg-slate-100 rounded-full h-2 overflow-hidden">
                                  <div
                                    className="h-full rounded-full bg-gradient-to-r from-indigo-400 to-purple-400 transition-all duration-300"
                                    style={{ width: `${(monthCompleted / monthTotal) * 100}%` }}
                                  />
                                </div>
                              </div>
                              <svg
                                className={`w-5 h-5 text-slate-400 transition-transform duration-300 ${
                                  isExpanded ? 'rotate-180' : ''
                                }`}
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                              >
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                              </svg>
                            </div>
                          </div>
                        </button>

                        {/* Expanded Content */}
                        {isExpanded && (
                          <div className="px-5 sm:px-6 pb-6 border-t border-slate-100 pt-5 space-y-6 animate-in">
                            {/* Goals */}
                            <div>
                              <h4 className="text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
                                <span className="w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center text-xs">
                                  🎯
                                </span>
                                Monthly Goals
                              </h4>
                              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                {month.goals.map((goal, idx) => (
                                  <li key={idx} className="flex items-start gap-2 text-sm text-slate-600">
                                    <span className="text-green-500 mt-0.5">✓</span>
                                    {goal}
                                  </li>
                                ))}
                              </ul>
                            </div>

                            {/* Topics */}
                            <div>
                              <h4 className="text-sm font-bold text-slate-700 mb-3 flex items-center gap-2">
                                <span className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-xs">
                                  📋
                                </span>
                                Study Topics
                              </h4>
                              <div className="space-y-3">
                                {monthTopics.map((topic) => (
                                  <div
                                    key={topic.id}
                                    className={`p-4 rounded-xl border transition-all ${
                                      completedTopics.has(topic.id)
                                        ? 'bg-green-50 border-green-200'
                                        : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                                    }`}
                                  >
                                    <div className="flex items-start gap-3">
                                      <button
                                        onClick={() => toggleTopic(topic.id)}
                                        className={`mt-0.5 w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all flex-shrink-0 ${
                                          completedTopics.has(topic.id)
                                            ? 'bg-green-500 border-green-500'
                                            : 'border-slate-300 hover:border-indigo-400'
                                        }`}
                                      >
                                        {completedTopics.has(topic.id) && (
                                          <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                          </svg>
                                        )}
                                      </button>
                                      <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                                          <h5
                                            className={`font-semibold text-sm ${
                                              completedTopics.has(topic.id) ? 'text-green-700 line-through' : 'text-slate-800'
                                            }`}
                                          >
                                            {topic.title}
                                          </h5>
                                          <span
                                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${skillColors[topic.skill].bg} ${skillColors[topic.skill].text}`}
                                          >
                                            {skillIcons[topic.skill]} {topic.skill}
                                          </span>
                                        </div>
                                        <p className="text-xs text-slate-500 mb-2">{topic.description}</p>
                                        <div className="flex flex-wrap gap-1">
                                          {topic.resources.map((resource, idx) => (
                                            <span
                                              key={idx}
                                              className="inline-flex items-center gap-1 px-2 py-0.5 bg-white border border-slate-200 rounded-md text-xs text-slate-600"
                                            >
                                              📎 {resource}
                                            </span>
                                          ))}
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Milestones */}
                            <div>
                              <h4 className="text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
                                <span className="w-6 h-6 rounded-full bg-purple-100 flex items-center justify-center text-xs">
                                  🏆
                                </span>
                                Milestones
                              </h4>
                              <div className="flex flex-wrap gap-2">
                                {month.milestones.map((milestone, idx) => (
                                  <span
                                    key={idx}
                                    className="inline-flex items-center gap-1 px-3 py-1.5 bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-lg text-xs font-medium text-purple-700"
                                  >
                                    ⭐ {milestone}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        ))}

        {/* Tips Section */}
        <div className="mt-12 bg-white rounded-2xl shadow-xl border border-slate-200 p-6 sm:p-8">
          <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white text-lg">
              💡
            </span>
            Essential Study Tips
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              {
                icon: '📅',
                title: 'Consistency Over Intensity',
                desc: 'Study 1-2 hours daily rather than cramming. Regular practice builds lasting skills.',
              },
              {
                icon: '🎧',
                title: 'Immerse in English',
                desc: 'Listen to podcasts, watch English shows, and read English articles every day.',
              },
              {
                icon: '📝',
                title: 'Practice Under Timed Conditions',
                desc: 'Always practice with a timer. Exam conditions are different from casual practice.',
              },
              {
                icon: '🔄',
                title: 'Review Mistakes Thoroughly',
                desc: 'Understanding why you got something wrong is more valuable than doing more tests.',
              },
              {
                icon: '🗣️',
                title: 'Speak English Daily',
                desc: 'Find a speaking partner, record yourself, or talk to yourself in English every day.',
              },
              {
                icon: '📊',
                title: 'Track Your Progress',
                desc: 'Keep a journal of scores, mistakes, and improvements. Celebrate small wins!',
              },
            ].map((tip, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-gradient-to-br from-slate-50 to-slate-100 border border-slate-200">
                <div className="text-2xl mb-2">{tip.icon}</div>
                <h3 className="font-bold text-slate-800 text-sm mb-1">{tip.title}</h3>
                <p className="text-xs text-slate-500">{tip.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Recommended Resources */}
        <div className="mt-8 bg-white rounded-2xl shadow-xl border border-slate-200 p-6 sm:p-8">
          <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center text-white text-lg">
              📚
            </span>
            Recommended Resources
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              {
                category: 'Official Materials',
                items: ['Cambridge IELTS 14-18', 'Official IELTS Practice Materials', 'IELTS.org free resources', 'British Council prep'],
              },
              {
                category: 'Online Platforms',
                items: ['IELTS Liz', 'IELTS Advantage', 'IELTS Buddy', 'Mini-IELTS.com'],
              },
              {
                category: 'Books',
                items: ['Grammar in Use (Murphy)', 'Vocabulary for IELTS', 'The Official Cambridge Guide', "Barron's IELTS"],
              },
              {
                category: 'Apps & Tools',
                items: ['Anki (flashcards)', 'Grammarly', 'Write & Improve', 'IELTS Word Power'],
              },
            ].map((section, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <h3 className="font-bold text-slate-700 text-sm mb-3">{section.category}</h3>
                <ul className="space-y-2">
                  {section.items.map((item, itemIdx) => (
                    <li key={itemIdx} className="text-xs text-slate-600 flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-12 pb-8 text-center">
          <p className="text-sm text-slate-400">
            🎯 IELTS 14-Month Roadmap • Track your progress and achieve your target band score!
          </p>
          <p className="text-xs text-slate-300 mt-2">
            Progress is saved automatically in your browser
          </p>
        </footer>
      </main>
    </div>
  );
}

export default App;
